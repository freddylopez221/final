<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=localhost;dbname=proyecto',
    'username' => 'postgres',
    'password' => '1c11ba1528',
    
];
